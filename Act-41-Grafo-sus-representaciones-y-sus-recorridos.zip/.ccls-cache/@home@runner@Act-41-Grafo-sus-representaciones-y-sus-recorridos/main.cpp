/*
 * main.cpp
 *
 *      Author: Sebastian Flores Lemus
 */
#include <iostream>
#include <cstring>
#include "ugraph.h"


int main(int argc, char* argv[]) {
	/************************ UMatrixGraph *********************/
	UMatrixGraph<char> umg(5);
	
	umg.addEdge('A', 'B');
	umg.addEdge('B', 'C');
	umg.addEdge('B', 'D');
	umg.addEdge('C', 'E');
	umg.addEdge('D', 'C');
	umg.addEdge('E', 'D');

  std::cout << "Matriz\n";
	std::cout << umg.toString();
	
	std::set<char> edges = umg.getConnectionFrom('B');
	std::set<char>::iterator itr;
	
	std::cout << "\n\n";

	UListGraph<char> ulg(5);
	
	ulg.addEdge('A', 'B');
	ulg.addEdge('B', 'C');
	ulg.addEdge('B', 'D');
	ulg.addEdge('C', 'E');
	ulg.addEdge('D', 'C');
	ulg.addEdge('E', 'D');

  std::cout << "Lista\n\n";
	std::cout << ulg.toString();
  
	std::cout << "\n\n";

  std::cout << "BFS & DFS Matriz\n\n"; 

  std::cout << "DFS(A) ->\t";
	edges = dfs(&umg, 'A');
	for (itr = edges.begin(); itr != edges.end(); itr++) {
		std::cout << (*itr) << "\t";
	}
	
	std::cout << "\nBFS(B) ->\t";
	edges = bfs(&umg,'B');
	for (itr = edges.begin(); itr != edges.end(); itr++) {
		std::cout << (*itr) << "\t";
	}
	std::cout << "\n\n";
	
	edges = ulg.getConnectionFrom('A');
	
	std::cout << "\n";

  std::cout << "BFS & DFS Lista\n\n"; 
	
	std::cout << "DFS(C) ->\t";
	edges = dfs(&ulg, 'C');
	for (itr = edges.begin(); itr != edges.end(); itr++) {
		std::cout << (*itr) << "\t";
	}
	std::cout << "\n\n";
	
	std::cout << "BFS(D) ->\t";
	edges = bfs(&ulg, 'D');
	for (itr = edges.begin(); itr != edges.end(); itr++) {
		std::cout << (*itr) << "\t";
	}
	std::cout << "\n\n";

  }